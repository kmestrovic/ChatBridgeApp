import React from 'react'

const Login=()=> {
  return (
    <div>Login
        <div>
            <form>
                <input type="text" placeholder="username"/>
            </form>
        </div>
    </div>
  )
}

export default Login