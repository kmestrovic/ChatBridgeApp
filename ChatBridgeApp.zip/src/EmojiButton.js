import React from 'react';
import EmojiPicker, { Emoji } from 'emoji-picker-react'

function EmojiButton() {
  return (
    <EmojiPicker/>
  )
}

export default EmojiButton